# Doc-Debt Tracker

"SonarQube for Documentation" — tracks drift between a codebase and its
documentation, and heals it with a Map-Reduce LLM pipeline once the drift
crosses a threshold. Every heal updates **two** documents per module:

- **Technical doc** — architecture, endpoints, data model, dependencies
- **Business doc** — features, use cases, user-facing impact

```
docdebt-project/
├── backend/     Spring Boot (Java 17, Maven) — API, scheduler, integrations
└── frontend/    React + Vite — Debt Heatmap dashboard
```

## 1. Prerequisites

- Java 17+, Maven 3.9+
- Node 18+
- A GitHub repo you can add a webhook to, and a GitHub **personal access token**
  (fine-grained, `Contents: Read` + `Pull requests: Read` on that repo) or a
  GitHub App token.
- A **Gemini API key** from [Google AI Studio](https://aistudio.google.com/apikey).

That's it — docs are stored as **plain local files** by default, so there's no
Microsoft/Entra setup needed to get the whole pipeline running end-to-end.

## 2. Configure environment variables

```bash
# GitHub
export GITHUB_TOKEN=ghp_xxx
export GITHUB_WEBHOOK_SECRET=some-random-string   # must match the webhook config in GitHub

# Gemini
export GEMINI_API_KEY=your-gemini-api-key
```

(Optional — see "Where docs are stored" below to change the local folders,
or "Moving to OneDrive later" to switch storage backends entirely.)

### GitHub webhook
In your repo: **Settings → Webhooks → Add webhook**
- Payload URL: `https://<your-backend-host>/webhook/github`
- Content type: `application/json`
- Secret: same value as `GITHUB_WEBHOOK_SECRET`
- Events: select **Pull requests** only

For local testing without a public URL, use [ngrok](https://ngrok.com) or
just use the dashboard's **Time Travel** button, which simulates PR merges
without needing a real webhook at all.

## 3. Run the backend

```bash
cd backend
mvn spring-boot:run
```

Starts on `http://localhost:8080`. Uses an embedded H2 file DB (`./data/docdebt.mv.db`)
by default — nothing to install. The H2 console is at `/h2-console` if you want
to inspect data (JDBC URL: `jdbc:h2:file:./data/docdebt;AUTO_SERVER=TRUE`).

### Where docs are stored

By default, healed docs land as plain Markdown files under:
```
./docs/Technical/Drafts/{ModuleName}-HLD.md
./docs/Business/Drafts/{ModuleName}-Business.md
```
Override the roots with `TECHNICAL_DOCS_ROOT` / `BUSINESS_DOCS_ROOT` env vars
if you'd rather point at existing doc folders in your repo. If a module's doc
already exists at that path (published, not draft), healing reads it and
folds the changes in; otherwise it's auto-scaffolded from a template.

### Switching to Postgres
```bash
export DB_URL=jdbc:postgresql://localhost:5432/docdebt
export DB_USERNAME=postgres
export DB_PASSWORD=postgres
export DB_DRIVER=org.postgresql.Driver
export DB_DIALECT=org.hibernate.dialect.PostgreSQLDialect
```

## 4. Run the frontend

```bash
cd frontend
npm install
npm run dev
```

Opens on `http://localhost:5173`, talking to the backend at `http://localhost:8080/api`
(override with `VITE_API_BASE_URL` if needed).

## 5. Demo flow (matches the plan's "Hackathon Demo Strategy")

1. Click **"+ Track module"** and add a module (name it after a real folder in
   your repo, e.g. `PaymentService`) — this is the **Debt Heatmap**.
2. Click **⚡ Time Travel** to simulate 5 rapid PR merges. Watch the gauge and
   heat pill spike toward red without waiting for real traffic.
3. Click **✚ Heal Now** to manually fire the Map-Reduce pipeline immediately.
   For **each** doc type (technical, business) it independently:
   - Pulls the matching half of each unprocessed PR summary (engineering
     detail for technical, feature/use-case detail for business)
   - Runs semantic discovery (matches an existing doc of that type, or
     triggers auto-scaffolding of a brand-new one if nothing scores ≥ 0.85
     similarity)
   - Calls Gemini to synthesize the updated doc
   - Writes it to the Drafts folder
   - Shows a side-by-side **before/after diff**, with tabs to flip between
     the Technical and Business result

The nightly `@Scheduled` job (`docdebt.volatility.schedule-cron`, default 2am)
does step 3 automatically for any module whose score crosses 50 — no need to
demo that live, just point at the code.

## 6. Moving to OneDrive later

The storage layer is behind a `DocStorageService` interface with two
implementations already built:
- `LocalDocService` (default, `docdebt.storage.mode=local`) — plain files
- `OneDriveDocService` (`docdebt.storage.mode=onedrive`) — personal OneDrive
  via Microsoft Graph, delegated auth (device code flow)

To switch, set `DOC_STORAGE_MODE=onedrive` plus:
```bash
export ONEDRIVE_CLIENT_ID=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
```

**Registering the Entra app** (personal Microsoft accounts, e.g.
outlook.com/hotmail): personal accounts default to a placeholder "Microsoft
Services" tenant with no real directory attached, so app registration will
fail with `AADSTS16000` until you create your own free tenant first:

1. In an incognito window, go to **portal.azure.com** and sign in.
2. Click the gear icon → **Directories + subscriptions**. If a real tenant is
   already listed (not "Microsoft Services"), click **Switch** and skip to
   step 5.
3. Search **"Microsoft Entra ID"** → **Manage tenants** → **+ Create** →
   **Microsoft Entra ID** (this is a free, standalone flow — no subscription
   or card needed).
4. Fill in an organization name and initial domain, then **Review + Create**.
5. Switch into the new tenant (gear icon → Directories + subscriptions →
   Switch), then go to **Microsoft Entra ID → App registrations → New
   registration**:
   - Supported account types: **"Personal Microsoft accounts only"**
   - Leave Redirect URI blank
   - Under **Authentication**, enable **"Allow public client flows"**
   - Copy the **Application (client) ID** → `ONEDRIVE_CLIENT_ID`

Then run the one-time login from `backend/`:
```bash
mvn compile exec:java -Dexec.mainClass=com.docdebt.tools.OneDriveLoginTool
```
It prints a short code and a URL (`https://microsoft.com/devicelogin`) —
approve it once, and the tool caches an access + refresh token to
`./data/onedrive-token.json`. You only need to repeat this if you delete that
file or revoke consent.

## 7. What's stubbed vs. real

| Piece | Status |
|---|---|
| GitHub webhook receiver + signature verification | Real |
| PR diff fetching via GitHub REST API | Real |
| Gemini dual summarization (technical + business) / synthesis / embeddings | Real (needs `GEMINI_API_KEY`) |
| Local doc storage (read/write technical + business docs, Drafts folders) | Real, default |
| OneDrive doc storage (delegated auth, device code flow) | Real, opt-in (needs Entra app for personal accounts) |
| Semantic discovery (vector search) | Real but **in-memory** cosine similarity over embeddings stored on each `CodeModule` row (separate technical/business embeddings) — swap for pgvector/Pinecone before this leaves the hackathon |
| Module → code-folder inference | Naive heuristic (first path segment in the diff) — good enough for a demo, replace with CODEOWNERS parsing or an LLM classifier next |

## 8. Next steps beyond the hackathon

- Replace the naive module inference with a proper classifier or CODEOWNERS lookup.
- Move the vector index out of the `CodeModule` embedding columns into pgvector.
- Add auth (the API is currently open — fine for a demo, not for prod).
- Turn "push as Draft" into a real approval workflow / PR-style review.
- If OneDrive needs to serve multiple people's docs, replace the single
  cached token file with per-user token storage.
