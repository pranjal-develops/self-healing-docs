import { useEffect, useState, useCallback } from 'react'
import { api } from './api'
import DebtHeatmap from './components/DebtHeatmap.jsx'
import DiffView from './components/DiffView.jsx'
import NewModuleForm from './components/NewModuleForm.jsx'

export default function App() {
  const [modules, setModules] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [busyId, setBusyId] = useState(null)
  const [healResult, setHealResult] = useState(null)

  const refresh = useCallback(async () => {
    try {
      setError(null)
      const data = await api.listModules()
      setModules(data)
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    refresh()
    const interval = setInterval(refresh, 8000)
    return () => clearInterval(interval)
  }, [refresh])

  async function handleSimulate(id) {
    setBusyId(id)
    try {
      await api.simulate(id, 5)
      await refresh()
    } catch (e) {
      setError(e.message)
    } finally {
      setBusyId(null)
    }
  }

  async function handleHeal(id) {
    setBusyId(id)
    try {
      const result = await api.healNow(id)
      setHealResult(result)
      await refresh()
    } catch (e) {
      setError(e.message)
    } finally {
      setBusyId(null)
    }
  }

  return (
    <div className="app-shell">
      <header className="app-header">
        <div className="app-title">
          <span className="app-title-mark">§</span>
          <div>
            <h1>Doc&#8209;Debt Tracker</h1>
            <p className="app-subtitle">Drift monitor — code vs. HLD/LLD design docs</p>
          </div>
        </div>
        <NewModuleForm onCreated={refresh} />
      </header>

      {error && <div className="banner-error">Couldn't reach the backend: {error}</div>}

      {loading ? (
        <div className="empty-state">Reading the fault lines…</div>
      ) : modules.length === 0 ? (
        <div className="empty-state">
          No modules tracked yet. Add one above, or wait for the first PR merge webhook.
        </div>
      ) : (
        <DebtHeatmap
          modules={modules}
          busyId={busyId}
          onSimulate={handleSimulate}
          onHeal={handleHeal}
        />
      )}

      {healResult && (
        <DiffView result={healResult} onClose={() => setHealResult(null)} />
      )}
    </div>
  )
}
