import { useState } from 'react'
import { api } from '../api'

export default function NewModuleForm({ onCreated }) {
  const [open, setOpen] = useState(false)
  const [name, setName] = useState('')
  const [technicalDocPath, setTechnicalDocPath] = useState('')
  const [businessDocPath, setBusinessDocPath] = useState('')
  const [submitting, setSubmitting] = useState(false)

  async function submit(e) {
    e.preventDefault()
    if (!name.trim()) return
    setSubmitting(true)
    try {
      await api.createModule(
        name.trim(),
        technicalDocPath.trim() || null,
        businessDocPath.trim() || null
      )
      setName('')
      setTechnicalDocPath('')
      setBusinessDocPath('')
      setOpen(false)
      onCreated()
    } finally {
      setSubmitting(false)
    }
  }

  if (!open) {
    return (
      <button className="btn btn-primary" onClick={() => setOpen(true)}>
        + Track module
      </button>
    )
  }

  return (
    <form className="new-module-form" onSubmit={submit}>
      <input
        placeholder="Module name (e.g. PaymentService)"
        value={name}
        onChange={(e) => setName(e.target.value)}
        autoFocus
      />
      <input
        placeholder="Technical doc path (optional)"
        value={technicalDocPath}
        onChange={(e) => setTechnicalDocPath(e.target.value)}
      />
      <input
        placeholder="Business doc path (optional)"
        value={businessDocPath}
        onChange={(e) => setBusinessDocPath(e.target.value)}
      />
      <button className="btn btn-primary" type="submit" disabled={submitting}>
        {submitting ? 'Adding…' : 'Add'}
      </button>
      <button className="btn btn-ghost" type="button" onClick={() => setOpen(false)}>
        Cancel
      </button>
    </form>
  )
}
