const HEAT_LABEL = {
  LOW: 'Stable',
  MEDIUM: 'Drifting',
  HIGH: 'Critical',
}

function DriftGauge({ score, threshold, heat }) {
  // Semi-circular gauge, needle angle proportional to score (capped at 2x threshold)
  const capped = Math.min(score, threshold * 2)
  const pct = capped / (threshold * 2)
  const angle = -90 + pct * 180 // -90deg (empty) to +90deg (full)

  return (
    <div className={`gauge gauge-${heat.toLowerCase()}`} aria-label={`Volatility score ${score}`}>
      <svg viewBox="0 0 100 55" width="96" height="54">
        <path d="M 6 50 A 44 44 0 0 1 94 50" className="gauge-track" />
        <path
          d="M 6 50 A 44 44 0 0 1 94 50"
          className="gauge-fill"
          style={{ strokeDasharray: `${pct * 138}, 138` }}
        />
        <line
          x1="50" y1="50" x2="50" y2="14"
          className="gauge-needle"
          style={{ transform: `rotate(${angle}deg)`, transformOrigin: '50px 50px' }}
        />
        <circle cx="50" cy="50" r="3" className="gauge-hub" />
      </svg>
      <div className="gauge-score">{score}</div>
    </div>
  )
}

export default function DebtHeatmap({ modules, busyId, onSimulate, onHeal }) {
  return (
    <div className="heatmap-grid">
      {modules.map((m) => (
        <article key={m.id} className={`module-card heat-${m.heatLevel.toLowerCase()}`}>
          <div className="module-card-top">
            <h3>{m.name}</h3>
            <span className={`heat-pill heat-pill-${m.heatLevel.toLowerCase()}`}>
              {HEAT_LABEL[m.heatLevel]}
            </span>
          </div>

          <DriftGauge score={m.volatilityScore} threshold={50} heat={m.heatLevel} />

          <dl className="module-stats">
            <div>
              <dt>Unprocessed PRs</dt>
              <dd>{m.unprocessedSummaries}</dd>
            </div>
            <div>
              <dt>Days since doc update</dt>
              <dd>{m.daysSinceLastUpdate}</dd>
            </div>
          </dl>

          {(m.technicalScaffolded || m.businessScaffolded) && (
            <div className="badge-row">
              {m.technicalScaffolded && <span className="badge-scaffolded">New technical doc</span>}
              {m.businessScaffolded && <span className="badge-scaffolded">New business doc</span>}
            </div>
          )}

          <div className="module-card-actions">
            <button
              className="btn btn-ghost"
              disabled={busyId === m.id}
              onClick={() => onSimulate(m.id)}
              title="Simulate 5 rapid PR merges"
            >
              ⚡ Time Travel
            </button>
            <button
              className="btn btn-primary"
              disabled={busyId === m.id}
              onClick={() => onHeal(m.id)}
              title="Run the Map-Reduce healing pipeline now"
            >
              {busyId === m.id ? 'Healing…' : '✚ Heal Now'}
            </button>
          </div>
        </article>
      ))}
    </div>
  )
}
