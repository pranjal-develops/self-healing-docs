import { useState } from 'react'

function DocDiff({ result }) {
  return (
    <div className="diff-columns">
      <div className="diff-column">
        <h4>Before</h4>
        <pre>{result.oldContent && result.oldContent.length ? result.oldContent : '(no existing document — this was unmapped)'}</pre>
      </div>
      <div className="diff-column diff-column-new">
        <h4>After (draft)</h4>
        <pre>{result.newContent}</pre>
      </div>
    </div>
  )
}

export default function DiffView({ result, onClose }) {
  const { moduleName, technical, business, summariesFolded } = result
  const [tab, setTab] = useState('technical')
  const active = tab === 'technical' ? technical : business

  return (
    <div className="diff-overlay" role="dialog" aria-modal="true">
      <div className="diff-panel">
        <div className="diff-header">
          <div>
            <h2>{moduleName} — docs healed</h2>
            <p className="diff-meta">
              Folded {summariesFolded} PR summar{summariesFolded === 1 ? 'y' : 'ies'} into both docs
            </p>
          </div>
          <button className="btn btn-ghost" onClick={onClose}>Close ✕</button>
        </div>

        <div className="diff-tabs">
          <button
            className={`diff-tab ${tab === 'technical' ? 'diff-tab-active' : ''}`}
            onClick={() => setTab('technical')}
          >
            Technical {technical.wasScaffolded && <span className="diff-tab-badge">new</span>}
          </button>
          <button
            className={`diff-tab ${tab === 'business' ? 'diff-tab-active' : ''}`}
            onClick={() => setTab('business')}
          >
            Business {business.wasScaffolded && <span className="diff-tab-badge">new</span>}
          </button>
          <span className="diff-tab-path"><code>{active.draftPath}</code></span>
        </div>

        <DocDiff result={active} />
      </div>
    </div>
  )
}
