const BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8080/api'

async function handle(res) {
  if (!res.ok) {
    let message = res.statusText
    try {
      const contentType = res.headers.get('content-type') || ''
      if (contentType.includes('application/json')) {
        const body = await res.json()
        message = body.message || JSON.stringify(body)
      } else {
        message = (await res.text()) || message
      }
    } catch {
      // fall back to statusText
    }
    throw new Error(message)
  }
  return res.json()
}

export const api = {
  listModules: () => fetch(`${BASE_URL}/modules`).then(handle),

  createModule: (name, technicalDocPath, businessDocPath) =>
    fetch(`${BASE_URL}/modules`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, technicalDocPath, businessDocPath }),
    }).then(handle),

  healNow: (id) =>
    fetch(`${BASE_URL}/modules/${id}/heal`, { method: 'POST' }).then(handle),

  simulate: (id, count = 5) =>
    fetch(`${BASE_URL}/modules/${id}/simulate?count=${count}`, {
      method: 'POST',
    }).then(handle),
}
